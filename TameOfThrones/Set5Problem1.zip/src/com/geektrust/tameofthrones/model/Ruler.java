package com.geektrust.tameofthrones.model;

import java.util.ArrayList;
import java.util.List;

public class Ruler {
	String name;
	Kingdom kingdom;
	List<Kingdom> allies;
	
	public Ruler(String name, Kingdom kingdom) {
		super();
		this.name = name;
		this.kingdom = kingdom;
		this.allies= new ArrayList<>();
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Kingdom> getAllies() {
		return allies;
	}
	public void setAllies(List<Kingdom> allies) {
		this.allies = allies;
	}

	public void addAllies(Kingdom kingdom2) {
		allies.add(kingdom2);
		
	}
	
}
