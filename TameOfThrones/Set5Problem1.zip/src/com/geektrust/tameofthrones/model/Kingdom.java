package com.geektrust.tameofthrones.model;

public class Kingdom {
	String name;
	String emblem;
	
	public Kingdom(String name, String emblem) {
		super();
		this.name = name;
		this.emblem = emblem;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmblem() {
		return emblem;
	}

	public void setEmblem(String emblem) {
		this.emblem = emblem;
	}

	@Override
	public String toString() {
		return "Kingdom [name=" + name + ", emblem=" + emblem + "]";
	}
	
}
